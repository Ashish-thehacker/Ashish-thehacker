
# Movie App

This is a movie browsing application built with React. The application fetches data from The Movie Database (TMDB) API and allows users to search, filter, and save favorite movies.

## Features

- **Movie Listing:** Displays a list of popular movies on the homepage.
- **Search:** Users can search for movies by title.
- **Infinite Scrolling:** Loads more movies as the user scrolls or clicks "Load More".
- **Filtering:** Users can filter movies by genre, release year, and rating (filters can be expanded).
- **Favorites:** Users can save favorite movies to local storage.
- **Responsive Design:** The application is mobile-first and adapts to different screen sizes.

## Folder Structure

- `components/` - Contains reusable React components such as `MovieCard`, `SearchBar`, and `Filter`.
- `pages/` - Contains page-level components, including `HomePage`.
- `services/` - Contains API service files, including `movieApi.js` for interacting with the TMDB API.
- `styles/` - Contains CSS files for styling the components.

## How to Run

1. Clone the repository.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Replace `your_tmdb_api_key` in `src/services/movieApi.js` with your TMDB API key.
4. Start the development server:
   ```bash
   npm start
   ```

## Possible Improvements

- Add more filtering options (e.g., multiple genres, range sliders for rating).
- Implement server-side rendering for better SEO.
- Add unit and integration tests using Jest and React Testing Library.
- Optimize image loading with lazy loading techniques.

## License

This project is licensed under the MIT License.
        