
import React from 'react';
import './MovieCard.css';

const MovieCard = ({ movie }) => {
    const handleFavorite = () => {
        const favorites = JSON.parse(localStorage.getItem('favorites')) || [];
        localStorage.setItem('favorites', JSON.stringify([...favorites, movie]));
    };

    return (
        <div className="movie-card">
            <img src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`} alt={movie.title} />
            <div className="movie-info">
                <h3>{movie.title}</h3>
                <p>{movie.release_date.split('-')[0]}</p>
                <button onClick={handleFavorite}>Add to Favorites</button>
            </div>
        </div>
    );
};

export default MovieCard;
        