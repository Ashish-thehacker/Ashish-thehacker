
import React from 'react';

const Filter = ({ onFilter }) => {
    const handleGenreChange = (e) => {
        onFilter({ genre: e.target.value });
    };

    // Implement similar handlers for year and rating

    return (
        <div className="filter">
            <select onChange={handleGenreChange}>
                <option value="">All Genres</option>
                <option value="28">Action</option>
                <option value="35">Comedy</option>
                {/* Add more genres as necessary */}
            </select>
            {/* Add similar select inputs for release year and rating */}
        </div>
    );
};

export default Filter;
        