
import axios from 'axios';

const API_KEY = 'your_tmdb_api_key';
const BASE_URL = 'https://api.themoviedb.org/3';

export const fetchMovies = (query, page = 1) => {
    return axios.get(`${BASE_URL}/search/movie`, {
        params: {
            api_key: API_KEY,
            query,
            page,
        },
    });
};

export const fetchPopularMovies = (page = 1) => {
    return axios.get(`${BASE_URL}/movie/popular`, {
        params: {
            api_key: API_KEY,
            page,
        },
    });
};
        