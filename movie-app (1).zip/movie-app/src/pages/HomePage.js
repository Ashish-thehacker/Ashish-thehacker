
import React, { useState, useEffect } from 'react';
import { fetchMovies, fetchPopularMovies } from '../services/movieApi';
import MovieCard from '../components/MovieCard';
import SearchBar from '../components/SearchBar';
import Filter from '../components/Filter';

const HomePage = () => {
    const [movies, setMovies] = useState([]);
    const [page, setPage] = useState(1);
    const [query, setQuery] = useState('');

    useEffect(() => {
        if (query) {
            searchMovies();
        } else {
            loadMovies();
        }
    }, [page, query]);

    const searchMovies = async () => {
        const response = await fetchMovies(query, page);
        setMovies([...movies, ...response.data.results]);
    };

    const loadMovies = async () => {
        const response = await fetchPopularMovies(page);
        setMovies([...movies, ...response.data.results]);
    };

    const handleSearch = (searchQuery) => {
        setQuery(searchQuery);
        setMovies([]);
        setPage(1);
    };

    const applyFilter = (filter) => {
        // Implement filtering logic based on selected filters
    };

    const loadMoreMovies = () => {
        setPage(page + 1);
    };

    return (
        <div className="movie-list">
            <SearchBar onSearch={handleSearch} />
            <Filter onFilter={applyFilter} />
            {movies.map(movie => (
                <MovieCard key={movie.id} movie={movie} />
            ))}
            <button onClick={loadMoreMovies}>Load More</button>
        </div>
    );
};

export default HomePage;
        