import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useInView } from 'react-intersection-observer';
import './App.css';

const API_KEY = 'YOUR_TMDB_API_KEY'; // Replace with your TMDB API Key

function App() {
  const [movies, setMovies] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(1);
  const [favorites, setFavorites] = useState(() => JSON.parse(localStorage.getItem('favorites')) || []);
  const { ref, inView } = useInView();

  useEffect(() => {
    if (inView) {
      fetchMovies();
    }
  }, [inView, page, searchTerm]);

  const fetchMovies = async () => {
    const response = await axios.get(`https://api.themoviedb.org/3/search/movie`, {
      params: {
        api_key: API_KEY,
        query: searchTerm,
        page: page,
      },
    });
    setMovies(prevMovies => [...prevMovies, ...response.data.results]);
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
    setMovies([]);
    setPage(1);
  };

  const handleFavoriteToggle = (movie) => {
    const newFavorites = favorites.includes(movie.id)
      ? favorites.filter(id => id !== movie.id)
      : [...favorites, movie.id];

    setFavorites(newFavorites);
    localStorage.setItem('favorites', JSON.stringify(newFavorites));
  };

  useEffect(() => {
    if (searchTerm) {
      setPage(1);
      setMovies([]);
    }
  }, [searchTerm]);

  return (
    <div className="App">
      <h1>Movie Browser</h1>
      <input
        type="text"
        placeholder="Search for movies..."
        value={searchTerm}
        onChange={handleSearchChange}
        aria-label="Search for movies"
      />
      <div className="movie-list">
        {movies.map(movie => (
          <div key={movie.id} className="movie-card">
            <img src={`https://image.tmdb.org/t/p/w200${movie.poster_path}`} alt={movie.title} />
            <h3>{movie.title}</h3>
            <p>{movie.release_date?.split('-')[0]}</p>
            <button onClick={() => handleFavoriteToggle(movie)}>
              {favorites.includes(movie.id) ? 'Unfavorite' : 'Favorite'}
            </button>
          </div>
        ))}
      </div>
      <div ref={ref} style={{ height: '20px' }} />
    </div>
  );
}

export default App;
