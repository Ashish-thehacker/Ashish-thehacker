
import React from 'react';

const Filter = ({ onFilter }) => {
  const handleGenreChange = (e) => {
    onFilter({ genre: e.target.value });
  };

  return (
    <div className="filter">
      <select onChange={handleGenreChange}>
        <option value="">All Genres</option>
        <option value="28">Action</option>
        <option value="35">Comedy</option>
      </select>
    </div>
  );
};

export default Filter;
